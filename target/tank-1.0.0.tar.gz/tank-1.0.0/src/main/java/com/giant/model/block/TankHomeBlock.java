package com.giant.model.block;

import com.giant.constant.ImageConstant;

public class TankHomeBlock extends DefaultBlock {
    public TankHomeBlock(int x, int y) {
        super(x, y);
    }

    public TankHomeBlock() {
        super();
        this.setId(TANK_HOME_BLOCK);
    }

}
