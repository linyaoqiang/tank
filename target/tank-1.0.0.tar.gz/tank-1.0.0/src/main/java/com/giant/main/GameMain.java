package com.giant.main;

import com.giant.frame.GameFrame;

/**
 * 进行游戏Main类
 */
public class GameMain {
    public static void main(String[] args) {
        new GameFrame();
    }
}


