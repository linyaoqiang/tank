package com.giant.model.map;

import com.giant.model.LevelInformation;
import com.giant.model.tank.EnemyTank;
import com.giant.model.tank.EnemyTankCamp;

import java.util.ArrayList;
import java.util.List;

public class LevelGameMap extends GameMap {
    public LevelGameMap() {
        this.setMapBlocks(new ArrayList<>());
    }

}
